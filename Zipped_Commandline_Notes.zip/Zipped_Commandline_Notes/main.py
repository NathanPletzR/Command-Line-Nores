from rich import print



"""
Command Line note:
    Create and Manage note's in the command line 
    Command List:
        new
        edit
        delete
        show
        showall
        deleteall
        help
        stop
"""

COMMAND_LIST = '''new - Create a new note  
                edit \'note_Name\'- Edit note of name \'note_Name\' 
                delete \'note_Name\'- Delete note of name \'note_Name\'  
                show \'note_Name\'- Show note of name \'note_Name\' 
                showall - Show all note\'s 
                deleteall - Delete all note\'s requires confirmation 
                help - Shows a list of all commands
                stop - Terminates program'''
                
FILE_PATH = 'notes.txt'

global user_string_list

command_dict = {'new': 1,
                'edit': 2,
                'delete': 3,
                'show': 4,
                'showall': 5,
                'deleteall': 6,
                'help': 7,
                'stop': 8}
                

#note's are added in the form [name, contents]   
note_list = []

def print_note(index):
    print('Name: ' + note_list[index][0] + '\n' +
          'Contents: ' + note_list[index][1] + '\n')
             
                
def new():
    print('[bold yellow]Enter note name:')
    name = input('\n')
    print('[bold yellow]Enter the contents of the note:')
    contents = input('\n')
    note_list.append([name, contents])
    print('[bold green]Created note:\n')
    print_note(note_list.index([name, contents]))
    run()
    

def edit():
    print('[bold yellow]\nWhat note would you like to edit?(Enter the name of the note)')
    note_name = input('\n')
    for note in note_list:
        if note_name == note[0]:
            print(note[0] + '\n')
            note[0] = input('\nEnter a new name: \n')
            print(note[1] + '\n')
            note[1] = input('\nEnter new contents: \n')
            
            print_note(note_list.index(note))
            
            run()

        else:
            print('[bold red][italic]\nThat note doesn\'t exist enter command [/bold red][bold yellow]\'showall\'[/bold yellow][bold red] to see all note\'s')
            run()
        
        
def delete():
    print('[bold yellow]\nWhat note would you like to delete?(Enter the name of the note)')
    note_name = input('\n')
    for note in note_list:
        if note_name == note[0]:
            try:
                note_list.remove(note)
                run()
            except Exception:
                print('[bold red][italic]\nThat note doesn\'t exist enter command [/bold red][bold yellow]\'showall\'[/bold yellow][bold red] to see all note\'s')
                run()
                
                
def show():
    print('[bold yellow]\nWhat note would you like to show?(Enter the name of the note)')
    note_name = input('\n')
    for note in note_list:
        if note_name == note[0]:
            print_note(note_list.index(note))
        else:
            print('[bold red][italic]\nThat note doesn\'t exist enter command [/bold red][bold yellow]\'showall\'[/bold yellow][bold red] to see all note\'s')


def showall():
    print('\n')
    for note in note_list:
        print_note(note_list.index(note))
        print('\n')
    run()


def deleteall():
    print('[bold yellow]\nAre you sure you would like to delete all note\'s (y/n)')
    confirmation = input('\n')
    if lower(confirmation) == 'y':
        for note in note_list:
            note_list.remove(note)
        print('[bold green]\nAll note\'s have been deleted successfully')
        run()
    else:
        run()

def help_():
    print('[bold orange]'+COMMAND_LIST+'[/bold orange]')
    run()
    
    
def stop():
    print('[bold green]\nProgram Terminated Successfully')
    
    
switcher = {1: new,
            2: edit,
            3: delete,
            4: show, 
            5: showall,
            6: deleteall,
            7: help_,
            8: stop}

    
def run():
    file_append = open(FILE_PATH, 'a+')
    file_append.truncate(0)
    for note in note_list:
        file_append.write(note[0] + '+' + note[1] + '\n')
    file_append.close()
    print('[bold yellow]\nWhat will you do?')
    user_string = input('\n')
    user_string_list = user_string.split(' ')
        
    val = command_dict.get(user_string_list[0], -1)
    if val == -1:
        print('[bold red][italic]\nThe Command you entered doesn\'t exist type [/bold red][bold yellow]\'help\'[/bold yellow][bold red] for a list of available commands')
        run()
    else:
        func = switcher.get(val, lambda: "Invalid Command")
        func()
    
if __name__ == '__main__':
    file_write = open(FILE_PATH, 'a+')
    file_write.close()
    file_read = open(FILE_PATH, 'r+')
    lines = file_read.readlines()
    for line in lines:
        note_list.append(line.split('+'))
    file_read.close()
    run()
    